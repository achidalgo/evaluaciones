package Electrodomestico;

public class Principal {

	public static void main(String[] args) {
		
		Electrodomestico[] e =new Electrodomestico[10];
		
		//color, consumo_energetico, precio_base, peso, carga
		e[0] = new Lavadora("blanco", 'A', 0, 20, 7);
		e[1] = new Lavadora("rojo", 'F', 0, 25, 11);
		e[2] = new Lavadora("azul", 'B', 0, 35, 31);
		e[3] = new Lavadora("gris", 'C', 0, 21, 8);
		e[4] = new Lavadora("blanco", 'E', 0, 18, 6);
		
		//color, consumo_energetico, precio_base, peso, resolucion, sintonizador_TDT
		e[5] = new Television("negro", 'A', 0, 5, 14, false);
		e[6] = new Television("gris", 'A', 0, 50, 44, true);
		e[7] = new Television("rojo", 'C', 0, 6, 20, true);
		e[8] = new Television("negro", 'B', 0, 10, 30, true);
		e[9] = new Television("negro", 'A', 0, 8, 21, false);
		
		double tpl=0;//total precio lavadoras
		double tpt=0;//total precio televisores
							
		for (int i=0;i<10;i++) {
			if (e[i] instanceof Lavadora) {
				tpl=tpl+e[i].precioFinal();				
			}
			if (e[i] instanceof Television) {
				tpt=tpt+e[i].precioFinal();
			}
		}
		
		System.out.println("Precio total Lavadoras : "+tpl);
		System.out.println("Precio total Televisores : "+tpt);
		System.out.println("Precio total Electrodomesticos : "+(tpl+tpt));
	}

}
