package Electrodomestico;

public class Electrodomestico {
	
	protected final static String COLOR_DEF="blanco";
	protected final static char CONSUMO_ENERGETICO_DEF='F';
	protected final static double PRECIO_BASE_DEF=100000;
	protected final static double PESO_DEF=5; 
	
	private String color;
	private char consumo_energetico;
	private double precio_base;
	private double peso;
		
	public Electrodomestico(double PRECIO_BASE_DEF, double PESO_DEF, char CONSUMO_ENERGETICO_DEF, String COLOR_DEF) {
		super();
	}
	    
	public Electrodomestico() {
	    this(PRECIO_BASE_DEF, PESO_DEF, CONSUMO_ENERGETICO_DEF, COLOR_DEF);
	}

	public Electrodomestico(double precio_base, double peso) {
		super();
		this.precio_base = precio_base;
		this.peso = peso;
	}

    public Electrodomestico(String color, char consumo_energetico, double precio_base, double peso) {
    	super();
    	comprobarColor(color); 
    	//this.color = color;
    	comprobarConsumoEnergetico(consumo_energetico);
        //this.consumo_energetico = consumo_energetico;
        this.precio_base = precio_base;
        this.peso = peso;
    }

    
    
	public String getColor() {
		return color;
	}

	public void setColor(String color) {
		this.color = color;
	}

	public char getConsumo_energetico() {
		return consumo_energetico;
	}

	public void setConsumo_energetico(char consumo_energetico) {
		this.consumo_energetico = consumo_energetico;
	}

	public double getPrecio_base() {
		return precio_base;
	}

	public void setPrecio_base(double precio_base) {
		this.precio_base = precio_base;
	}

	public double getPeso() {
		return peso;
	}

	public void setPeso(double peso) {
		this.peso = peso;
	}

	public static String getColorDef() {
		return COLOR_DEF;
	}

	public static char getConsumoEnergeticoDef() {
		return CONSUMO_ENERGETICO_DEF;
	}

	public static double getPrecioBaseDef() {
		return PRECIO_BASE_DEF;
	}

	public static double getPesoDef() {
		return PESO_DEF;
	}

	private void comprobarConsumoEnergetico(char letra) {
		switch(letra) {
		  case 'A': setConsumo_energetico('A'); break;
		  case 'a': setConsumo_energetico('A'); break;
		  case 'B': setConsumo_energetico('B'); break;
		  case 'b': setConsumo_energetico('B'); break;
		  case 'C': setConsumo_energetico('C'); break;
		  case 'c': setConsumo_energetico('C'); break;
		  case 'D': setConsumo_energetico('D'); break;
		  case 'd': setConsumo_energetico('D'); break;		  
		  case 'E': setConsumo_energetico('E'); break;
		  case 'e': setConsumo_energetico('E'); break;	
		  case 'F': setConsumo_energetico('F'); break;
		  case 'f': setConsumo_energetico('F'); break;			  
		  default:
			  setConsumo_energetico(getConsumoEnergeticoDef());break;
		}
	}	
	
	private void comprobarColor(String color) {
		if ((color.equalsIgnoreCase("blanco"))||(color.equalsIgnoreCase("negro"))||(color.equalsIgnoreCase("rojo"))||(color.equalsIgnoreCase("azul"))||(color.equalsIgnoreCase("gris"))){
			setColor(color.toLowerCase());
		}else setColor(getColorDef());
		
	}

	public double precioFinal() {
		double aumento_energia=0;
		double aumento_peso=0;
		double preciofinal=0;
		
		switch(getConsumo_energetico()) {
		  case 'A': aumento_energia=85000; break;
		  case 'B': aumento_energia=70000; break;
		  case 'C': aumento_energia=50000; break;
		  case 'D': aumento_energia=40000; break;
		  case 'E': aumento_energia=25000; break;
		  case 'F': aumento_energia=8500; break;
		}
		
		if ((getPeso()>=0)&&(getPeso()<=19)) {
			aumento_peso=8500;
		}else if ((getPeso()>=20)&&(getPeso()<=49)) {
			aumento_peso=40000;
		}else if ((getPeso()>=50)&&(getPeso()<=79)) {
			aumento_peso=70000;
		}else if (getPeso()>=80) {
			aumento_peso=85000;
		}	
		
		preciofinal=getPrecioBaseDef()+aumento_energia+aumento_peso;
		
		return preciofinal;
	}
	
}
