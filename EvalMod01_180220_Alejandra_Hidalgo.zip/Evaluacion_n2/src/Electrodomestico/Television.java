package Electrodomestico;

public class Television extends Electrodomestico{

	public static final double RESOLUCION_DEF=20;
	public static final boolean SINTONIZADOR_TDT_DEF=false;	
	
	double resolucion;
	boolean sintonizador_TDT;
	
	public Television(double RESOLUCION_DEF, boolean SINTONIZADOR_TDT_DEF) {
		super();
	}

	public Television() {
		this(RESOLUCION_DEF, SINTONIZADOR_TDT_DEF);
	}

	public Television(double preciobase, double peso) {
		super(preciobase, peso);
	}

	public Television(String color, char consumo_energetico, double precio_base, double peso, double resolucion, boolean sintonizador_TDT) {
		super(color, consumo_energetico, precio_base, peso);
		this.resolucion = resolucion;
		this.sintonizador_TDT = sintonizador_TDT;	
	}

	public Television(double PRECIO_BASE_DEF, double PESO_DEF, char CONSUMO_ENERGETICO_DEF, String COLOR_DEF) {
		super(PRECIO_BASE_DEF, PESO_DEF, CONSUMO_ENERGETICO_DEF, COLOR_DEF);
	}

	public double getResolucion() {
		return resolucion;
	}

	public void setResolucion(double resolucion) {
		this.resolucion = resolucion;
	}

	public boolean isSintonizador_TDT() {
		return sintonizador_TDT;
	}

	public void setSintonizador_TDT(boolean sintonizador_TDT) {
		this.sintonizador_TDT = sintonizador_TDT;
	}

	public static double getResolucionDef() {
		return RESOLUCION_DEF;
	}

	public static boolean isSintonizadorTdtDef() {
		return SINTONIZADOR_TDT_DEF;
	}

	public double precioFinal() {

		double aumento= super.precioFinal();
		if (getResolucion()>40){	
			aumento= aumento*1.3;
		}
		if (isSintonizador_TDT()){	
			aumento= aumento+45000;
		}
		return aumento;	
		}
	


	
	
	
}
