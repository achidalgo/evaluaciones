package Electrodomestico;

public class Lavadora extends Electrodomestico{

	public static final double CARGA_DEF=5;
	
	double carga;
	
	public Lavadora(double CARGA_DEF) {	
		super();
	}
	
	public Lavadora() {
	    this(CARGA_DEF);
	}

	public Lavadora(double preciobase, double peso) {
		super(preciobase, peso);
	}
	
	public Lavadora(String color, char consumo_energetico, double precio_base, double peso, double carga) {
		super(color, consumo_energetico, precio_base, peso);
		this.carga = carga;
	}

	public Lavadora(double PRECIO_BASE_DEF, double PESO_DEF, char CONSUMO_ENERGETICO_DEF, String COLOR_DEF) {
		super(PRECIO_BASE_DEF, PESO_DEF, CONSUMO_ENERGETICO_DEF, COLOR_DEF);
	}


	public double getCarga() {
		return carga;
	}

	public void setCarga(double carga) {
		this.carga = carga;
	}

	public static double getCargaDef() {
		return CARGA_DEF;
	}

	public double precioFinal() {
	
		double aumento= super.precioFinal();
		if (getCarga()>30){
			aumento=aumento+40000;
		}
		return aumento;
	}
	
}
