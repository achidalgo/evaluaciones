package Evaluacion_02;
import javax.swing.JOptionPane;
 
public class Main_Automovil {

	public static void main(String[] args)  {
		Automovil auto = new Automovil();
		
		auto.setMarca(JOptionPane.showInputDialog(null,"Ingrese Marca"));
		auto.setModelo(JOptionPane.showInputDialog(null,"Ingrese Modelo"));
	    auto.setA�o(Integer.parseInt(JOptionPane.showInputDialog(null,"Ingrese A�o"))); 
		auto.setPrecio(Double.parseDouble(JOptionPane.showInputDialog(null,"Ingrese Precio")));		
		
		 JOptionPane.showMessageDialog(null,  
				   " AUTOMOVIL "
				+"\n Marca : "+auto.getMarca()					
				+"\n Modelo : "+auto.getModelo()
			 	+"\n A�o : "+auto.getA�o()
			 	+"\n Precio : "+auto.getPrecio()
			 	+"\n Precio Final : "+auto.preciofinal()
				);			
	}

}

